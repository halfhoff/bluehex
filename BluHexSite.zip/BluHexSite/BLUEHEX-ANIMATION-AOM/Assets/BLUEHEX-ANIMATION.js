(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes
lib.webFontTxtInst = {}; 
var loadedTypekitCount = 0;
var loadedGoogleCount = 0;
var gFontsUpdateCacheList = [];
var tFontsUpdateCacheList = [];

// library properties:
lib.properties = {
	width: 500,
	height: 500,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	webfonts: {},
	manifest: []
};



lib.ssMetadata = [];



lib.updateListCache = function (cacheList) {		
	for(var i = 0; i < cacheList.length; i++) {		
		if(cacheList[i].cacheCanvas)		
			cacheList[i].updateCache();		
	}		
};		

lib.addElementsToCache = function (textInst, cacheList) {		
	var cur = textInst;		
	while(cur != exportRoot) {		
		if(cacheList.indexOf(cur) != -1)		
			break;		
		cur = cur.parent;		
	}		
	if(cur != exportRoot) {	//we have found an element in the list		
		var cur2 = textInst;		
		var index = cacheList.indexOf(cur);		
		while(cur2 != cur) { //insert all it's children just before it		
			cacheList.splice(index, 0, cur2);		
			cur2 = cur2.parent;		
			index++;		
		}		
	}		
	else {	//append element and it's parents in the array		
		cur = textInst;		
		while(cur != exportRoot) {		
			cacheList.push(cur);		
			cur = cur.parent;		
		}		
	}		
};		

lib.gfontAvailable = function(family, totalGoogleCount) {		
	lib.properties.webfonts[family] = true;		
	var txtInst = lib.webFontTxtInst && lib.webFontTxtInst[family] || [];		
	for(var f = 0; f < txtInst.length; ++f)		
		lib.addElementsToCache(txtInst[f], gFontsUpdateCacheList);		

	loadedGoogleCount++;		
	if(loadedGoogleCount == totalGoogleCount) {		
		lib.updateListCache(gFontsUpdateCacheList);		
	}		
};		

lib.tfontAvailable = function(family, totalTypekitCount) {		
	lib.properties.webfonts[family] = true;		
	var txtInst = lib.webFontTxtInst && lib.webFontTxtInst[family] || [];		
	for(var f = 0; f < txtInst.length; ++f)		
		lib.addElementsToCache(txtInst[f], tFontsUpdateCacheList);		

	loadedTypekitCount++;		
	if(loadedTypekitCount == totalTypekitCount) {		
		lib.updateListCache(tFontsUpdateCacheList);		
	}		
};
// symbols:



(lib.Symbol10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#2F7878").p("AGojwImlj3ImnDxIgDHnIGlD3IGnjxg");
	this.shape.setTransform(42.5,48.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3E6E73").s().p("AmnDxIADnnIGnjxIGlD3IgDHnImnDxg");
	this.shape_1.setTransform(42.5,48.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,87,99.8);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#2F7878").p("AbSvfI7Fv4I7QPgIgOfXIbFP4IbQvgg");
	this.shape.setTransform(174.7,200.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3E6E73").s().p("A7RPgIAO/XIbQvgIbFP4IgOfXI7QPgg");
	this.shape_1.setTransform(174.7,200.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,351.3,403.8);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#80D1DF").s().p("AuwHLMgAughWIe9PEMgAQAlTg");
	this.shape.setTransform(100.8,170.4,1.016,1.016);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,201.6,340.7);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C1E6EC").s().p("AwJq9MAgjgPQMgA6Ai2I/6Rlg");
	this.shape.setTransform(106.8,170.6,1.016,1.016);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,213.6,341.1);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#9BD8DF").s().p("A/pADMAgNgPQIfGPRMggIAPKg");
	this.shape.setTransform(205.9,99,1.016,1.016);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,411.9,198);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#80D1DF").s().p("AuwHLMgAughWIe9PEMgAQAlTg");
	this.shape.setTransform(55.4,145.7,0.549,0.549);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C1E6EC").s().p("AwJq+MAgkgPPMgA7Ai2I/6Rlg");
	this.shape_1.setTransform(165.4,145.8,0.549,0.549);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#9BD8DF").s().p("A/pADMAgNgPQIfGPRMggIAPKg");
	this.shape_2.setTransform(111.3,53.5,0.549,0.549);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#2F7878").p("AbSvfI7Fv4I7QPgIgOfXIbFP4IbQvgg");
	this.shape_3.setTransform(111.8,122.9,0.549,0.549);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3E6E73").s().p("A7RPgIAO/XIbQvgIbFP4IgOfXI7QPgg");
	this.shape_4.setTransform(111.8,122.9,0.549,0.549);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,223.1,238);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#9BD8DF").s().p("Ax5ABISNonIRnIoIyMIlg");
	this.shape.setTransform(114.7,55.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,229.4,110.3);


(lib.Symbol13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol5();
	this.instance.parent = this;
	this.instance.setTransform(212.8,99,1,1,0,0,0,205.9,99);

	this.instance_1 = new lib.Symbol6();
	this.instance_1.parent = this;
	this.instance_1.setTransform(327.8,281.6,1,1,0,0,0,106.8,170.6);

	this.instance_2 = new lib.Symbol7();
	this.instance_2.parent = this;
	this.instance_2.setTransform(100.8,284.3,1,1,0,0,0,100.8,170.3);

	this.instance_3 = new lib.Symbol8();
	this.instance_3.parent = this;
	this.instance_3.setTransform(209.5,225.1,1,1,0,0,0,174.7,200.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,434.6,454.7);


(lib.Symbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol13();
	this.instance.parent = this;
	this.instance.setTransform(217.3,229.3,1,1,0,0,0,217.3,227.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:228.6},0).wait(1).to({y:227.9},0).wait(1).to({y:227.2},0).wait(1).to({y:226.5},0).wait(1).to({y:225.8},0).wait(1).to({y:225.1},0).wait(1).to({y:224.4},0).wait(1).to({y:223.7},0).wait(1).to({y:223},0).wait(1).to({y:222.3},0).wait(1).to({y:221.6},0).wait(1).to({y:220.8},0).wait(1).to({y:220.1},0).wait(1).to({y:219.4},0).wait(1).to({y:218.7},0).wait(1).to({y:218},0).wait(1).to({y:217.3},0).wait(1).to({y:216.6},0).wait(1).to({y:215.9},0).wait(1).to({y:215.2},0).wait(1).to({y:214.5},0).wait(1).to({y:213.8},0).wait(1).to({y:213},0).wait(1).to({y:212.3},0).wait(1).to({y:212.9},0).wait(1).to({y:213.5},0).wait(1).to({y:214.1},0).wait(1).to({y:214.7},0).wait(1).to({y:215.3},0).wait(1).to({y:215.9},0).wait(1).to({y:216.4},0).wait(1).to({y:217},0).wait(1).to({y:217.6},0).wait(1).to({y:218.2},0).wait(1).to({y:218.8},0).wait(1).to({y:219.4},0).wait(1).to({y:220},0).wait(1).to({y:220.5},0).wait(1).to({y:221.1},0).wait(1).to({y:221.7},0).wait(1).to({y:222.3},0).wait(1).to({y:222.9},0).wait(1).to({y:223.5},0).wait(1).to({y:224.1},0).wait(1).to({y:224.7},0).wait(1).to({y:225.2},0).wait(1).to({y:225.8},0).wait(1).to({y:226.4},0).wait(1).to({y:227},0).wait(1).to({y:227.5},0).wait(1).to({y:228.1},0).wait(1).to({y:228.7},0).wait(1).to({y:229.3},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,2,434.6,454.7);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol10();
	this.instance.parent = this;
	this.instance.setTransform(42.5,48.9,1,1,0,0,0,42.5,48.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:47.7},0).wait(1).to({y:46.5},0).wait(1).to({y:45.4},0).wait(1).to({y:44.2},0).wait(1).to({y:43.1},0).wait(1).to({y:42},0).wait(1).to({y:40.9},0).wait(1).to({y:39.9},0).wait(1).to({y:38.9},0).wait(1).to({y:37.8},0).wait(1).to({y:36.9},0).wait(1).to({y:35.9},0).wait(1).to({y:35},0).wait(1).to({y:34.1},0).wait(1).to({y:33.2},0).wait(1).to({y:33.5},0).wait(1).to({y:34.3},0).wait(1).to({y:35.1},0).wait(1).to({y:35.9},0).wait(1).to({y:36.6},0).wait(1).to({y:37.4},0).wait(1).to({y:38.1},0).wait(1).to({y:38.7},0).wait(1).to({y:39.4},0).wait(1).to({y:40},0).wait(1).to({y:40.6},0).wait(1).to({y:41.2},0).wait(1).to({y:41.7},0).wait(1).to({y:42.3},0).wait(1).to({y:42.8},0).wait(1).to({y:43.2},0).wait(1).to({y:43.7},0).wait(1).to({y:44.1},0).wait(1).to({y:44.5},0).wait(1).to({y:44.9},0).wait(1).to({y:45.3},0).wait(1).to({y:45.6},0).wait(1).to({y:46},0).wait(1).to({y:46.3},0).wait(1).to({y:46.5},0).wait(1).to({y:46.8},0).wait(1).to({y:47},0).wait(1).to({y:47.2},0).wait(1).to({y:47.4},0).wait(1).to({y:47.5},0).wait(1).to({y:47.7},0).wait(1).to({y:47.8},0).wait(2).to({y:47.9},0).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,86,98.9);


// stage content:



(lib.BLUEHEXANIMATION = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_95 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(95).call(this.frame_95).wait(2));

	// Layer 1
	this.instance = new lib.Symbol12();
	this.instance.parent = this;
	this.instance.setTransform(259.1,260.7,1,1,0,0,0,217.3,227.3);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(95).to({_off:false},0).wait(1).to({regY:220.8,y:254.2},0).wait(1));

	// Large Top
	this.instance_1 = new lib.Symbol5();
	this.instance_1.parent = this;
	this.instance_1.setTransform(255.2,144.1,1,1,0,0,0,205.9,99);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(80).to({_off:false},0).wait(1).to({y:142.8},0).wait(1).to({y:141.7},0).wait(1).to({y:140.5},0).wait(1).to({y:139.4},0).wait(1).to({y:138.4},0).wait(1).to({y:137.5},0).wait(1).to({y:136.6},0).wait(1).to({y:135.8},0).wait(1).to({y:135},0).wait(1).to({y:134.3},0).wait(1).to({y:133.7},0).wait(1).to({y:133.1},0).wait(1).to({y:132.6},0).wait(1).to({y:132.1},0).to({_off:true},1).wait(2));

	// Large-Right
	this.instance_2 = new lib.Symbol6();
	this.instance_2.parent = this;
	this.instance_2.setTransform(356.3,314.7,1,1,0,0,0,106.8,170.6);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(80).to({_off:false},0).wait(1).to({x:357.7},0).wait(1).to({x:359.1},0).wait(1).to({x:360.4},0).wait(1).to({x:361.7},0).wait(1).to({x:362.9},0).wait(1).to({x:364},0).wait(1).to({x:365},0).wait(1).to({x:366},0).wait(1).to({x:366.9},0).wait(1).to({x:367.7},0).wait(1).to({x:368.4},0).wait(1).to({x:369.1},0).wait(1).to({x:369.7},0).wait(1).to({x:370.3},0).to({_off:true},1).wait(2));

	// Large-left
	this.instance_3 = new lib.Symbol7();
	this.instance_3.parent = this;
	this.instance_3.setTransform(151.3,315.4,1,1,0,0,0,100.8,170.3);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(80).to({_off:false},0).wait(1).to({regY:170.4,x:150.4,y:315.7},0).wait(1).to({x:149.6,y:315.9},0).wait(1).to({x:148.9,y:316},0).wait(1).to({x:148.1,y:316.2},0).wait(1).to({x:147.5,y:316.4},0).wait(1).to({x:146.8,y:316.6},0).wait(1).to({x:146.3,y:316.7},0).wait(1).to({x:145.7,y:316.8},0).wait(1).to({x:145.2,y:317},0).wait(1).to({x:144.7,y:317.1},0).wait(1).to({x:144.3,y:317.2},0).wait(1).to({x:143.9,y:317.3},0).wait(1).to({x:143.6,y:317.4},0).wait(1).to({x:143.3,y:317.5},0).to({_off:true},1).wait(2));

	// Large-middle
	this.instance_4 = new lib.Symbol8();
	this.instance_4.parent = this;
	this.instance_4.setTransform(252,258.2,1,1,0,0,0,174.7,200.9);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(80).to({_off:false},0).wait(14).to({_off:true},1).wait(2));

	// Layer 1
	this.instance_5 = new lib.Symbol3();
	this.instance_5.parent = this;
	this.instance_5.setTransform(245,237.4,1,1,0,0,0,112,119);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(41).to({_off:false},0).wait(1).to({regX:111.6,scaleX:1.04,scaleY:1.04,rotation:-37.4,x:245.3,y:239},0).wait(1).to({scaleX:1.09,scaleY:1.09,rotation:-73.8,x:246.1,y:240.5},0).wait(1).to({scaleX:1.13,scaleY:1.13,rotation:-109.2,x:247,y:241.8},0).wait(1).to({scaleX:1.17,scaleY:1.17,rotation:-143.6,x:247.7,y:243},0).wait(1).to({scaleX:1.21,scaleY:1.21,rotation:-177,x:248.3,y:244},0).wait(1).to({scaleX:1.25,scaleY:1.25,rotation:-209.4,x:248.7,y:244.9},0).wait(1).to({scaleX:1.29,scaleY:1.29,rotation:-240.8,x:249.1,y:245.9},0).wait(1).to({scaleX:1.32,scaleY:1.32,rotation:-271.2,x:249.3,y:247.1},0).wait(1).to({scaleX:1.36,scaleY:1.36,rotation:-300.7,x:249.5,y:248.3},0).wait(1).to({scaleX:1.39,scaleY:1.39,rotation:-329.1,x:249.7,y:249.6},0).wait(1).to({scaleX:1.42,scaleY:1.42,rotation:-356.5,x:250.1,y:250.8},0).wait(1).to({scaleX:1.46,scaleY:1.46,rotation:-382.9,x:250.6,y:252.1},0).wait(1).to({scaleX:1.49,scaleY:1.49,rotation:-408.4,x:251.2,y:253.3},0).wait(1).to({scaleX:1.52,scaleY:1.52,rotation:-432.8,x:251.9,y:254.3},0).wait(1).to({scaleX:1.54,scaleY:1.54,rotation:-456.2,x:252.5,y:255.2},0).wait(1).to({scaleX:1.57,scaleY:1.57,rotation:-478.7,x:253.1,y:256},0).wait(1).to({scaleX:1.6,scaleY:1.6,rotation:-500.1,x:253.6,y:256.6},0).wait(1).to({scaleX:1.62,scaleY:1.62,rotation:-520.5,x:254,y:257.2},0).wait(1).to({scaleX:1.64,scaleY:1.64,rotation:-540,x:254.3,y:257.7},0).wait(1).to({scaleX:1.66,scaleY:1.66,rotation:-558.4,x:254.5,y:258.2},0).wait(1).to({scaleX:1.69,scaleY:1.69,rotation:-575.9,x:254.7,y:258.6},0).wait(1).to({scaleX:1.7,scaleY:1.7,rotation:-592.4,x:254.8,y:259.1},0).wait(1).to({scaleX:1.72,scaleY:1.72,rotation:-607.8,x:255,y:259.6},0).wait(1).to({scaleX:1.74,scaleY:1.74,rotation:-622.3,y:260.2},0).wait(1).to({scaleX:1.76,scaleY:1.76,rotation:-635.7,y:260.7},0).wait(1).to({scaleX:1.77,scaleY:1.77,rotation:-648.2,x:255.1,y:261.2},0).wait(1).to({scaleX:1.79,scaleY:1.79,rotation:-659.7,x:255.2,y:261.7},0).wait(1).to({scaleX:1.8,scaleY:1.8,rotation:-670.1,y:262.3},0).wait(1).to({scaleX:1.81,scaleY:1.81,rotation:-679.6,x:255.3,y:262.8},0).wait(1).to({scaleX:1.82,scaleY:1.82,rotation:-688.1,x:255.4,y:263.1},0).wait(1).to({scaleX:1.83,scaleY:1.83,rotation:-695.6,x:255.5,y:263.5},0).wait(1).to({scaleX:1.84,scaleY:1.84,rotation:-702,y:263.8},0).wait(1).to({scaleX:1.84,scaleY:1.84,rotation:-707.5,x:255.6,y:264},0).wait(1).to({scaleX:1.85,scaleY:1.85,rotation:-712,x:255.7,y:264.3},0).wait(1).to({scaleX:1.85,scaleY:1.85,rotation:-715.5,y:264.4},0).wait(1).to({scaleX:1.85,scaleY:1.85,rotation:-718,y:264.6},0).wait(1).to({scaleX:1.86,scaleY:1.86,rotation:-719.5,x:255.8},0).wait(1).to({rotation:-720,y:264.7},0).to({_off:true},1).wait(17));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#9BD8DF").s().p("Ax5ABISNonIRnIoIyMIlg");
	this.shape.setTransform(313.5,-195.7);

	this.instance_6 = new lib.Symbol2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(611.6,382.4,1,1,0,0,0,114.7,55.1);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_6}]},35).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_6}]},1).to({state:[]},1).wait(55));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(35).to({_off:false},0).wait(1).to({x:550.3,y:347.1},0).wait(1).to({x:488.9,y:311.7},0).wait(1).to({x:427.6,y:276.4},0).wait(1).to({x:366.2,y:241},0).wait(1).to({x:304.9,y:205.7},0).wait(1).to({x:243.6,y:170.3},0).to({_off:true},1).wait(55));

	// Right
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C1E6EC").s().p("AyHhqISNpuISCMyI06KAg");
	this.shape_1.setTransform(361.6,364.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C1E6EC").s().p("AxUgzISJptIQgLJI0bJ4g");
	this.shape_2.setTransform(356.6,358.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C1E6EC").s().p("AwhADISFpqIO+JhIz8Jug");
	this.shape_3.setTransform(351.5,353);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#C1E6EC").s().p("AvuA6ISApoINdH3IzdJmg");
	this.shape_4.setTransform(346.4,347.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C1E6EC").s().p("Au7ByIR8poIL8GOIy/Jfg");
	this.shape_5.setTransform(341.3,341.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#C1E6EC").s().p("AuICqIR4pnIKZEkIyeJXg");
	this.shape_6.setTransform(336.2,336.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#C1E6EC").s().p("AtWDhIR1plII4C6IyBJPg");
	this.shape_7.setTransform(331.1,330.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#C1E6EC").s().p("AsjEZIRwplIHXBRIxiJHg");
	this.shape_8.setTransform(326.1,325.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#C1E6EC").s().p("AF8klIF1gYIxDJAImeA8g");
	this.shape_9.setTransform(321,321.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#C1E6EC").s().p("AGrjvIETiDIwjI4IlYCtg");
	this.shape_10.setTransform(315.9,316.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#C1E6EC").s().p("AtUHFIapu7InBGAIyYJug");
	this.shape_11.setTransform(321.7,304.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#C1E6EC").s().p("AsVEEIYrtcIlPJEIyYJtg");
	this.shape_12.setTransform(316.6,294.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#C1E6EC").s().p("AreBcIW9sJIjsLrIyYJwg");
	this.shape_13.setTransform(312.2,286.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#C1E6EC").s().p("AqvgwIVfrFIiXN7IyZJwg");
	this.shape_14.setTransform(308.5,279);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#C1E6EC").s().p("AqJikIUTqMIhTPxIyYJwg");
	this.shape_15.setTransform(305.4,273.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#C1E6EC").s().p("Aprj/ITXpeIgdRLIyYJwg");
	this.shape_16.setTransform(303,268.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#C1E6EC").s().p("Apbk/ISto/IAKSNIyZJwg");
	this.shape_17.setTransform(301.8,265.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#C1E6EC").s().p("ApalmISUorIAgS0IyYJvg");
	this.shape_18.setTransform(301.9,263.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#C1E6EC").s().p("ApZlzISLolIAoTBIyZJwg");
	this.shape_19.setTransform(302,262.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#C1E6EC").s().p("ArRlzISLolIAnSsIDxhxIjwCAIAAAGIsgGpIgUALIgWALIlOCxg");
	this.shape_20.setTransform(313.9,262.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_1}]},10).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[]},13).wait(55));

	// Left
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#80D1DF").s().p("Av7hDIOtqQIRKK0IykL0g");
	this.shape_21.setTransform(142.6,356.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#80D1DF").s().p("AuviPIMWnIIRJKyIviH9g");
	this.shape_22.setTransform(150.1,343.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#80D1DF").s().p("AtjjbIJ+j/IRKKyIsjEDg");
	this.shape_23.setTransform(157.7,331.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#80D1DF").s().p("AsYknIHng3IRKKyIphAKg");
	this.shape_24.setTransform(165.3,318.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#80D1DF").s().p("AEtCzIv5pUIFQCRIRJKyg");
	this.shape_25.setTransform(172.8,310.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#80D1DF").s().p("AmejBIkfklIHfDbIOcLyg");
	this.shape_26.setTransform(174.4,304.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#80D1DF").s().p("Amth/IkAmsIJtElILuMyg");
	this.shape_27.setTransform(175.9,297.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#80D1DF").s().p("Am8g9IjioyIL6FuIJDNxg");
	this.shape_28.setTransform(177.4,291.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#80D1DF").s().p("AnSAVIisrhINpGnIGUPyg");
	this.shape_29.setTransform(179.9,282.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#80D1DF").s().p("AnjBbIiBtyIPEHUIEFRbg");
	this.shape_30.setTransform(181.9,275.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#80D1DF").s().p("AnxCQIhfvhIQMH3ICVStg");
	this.shape_31.setTransform(183.5,270.2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#80D1DF").s().p("An7C3IhHwyIQ/IQIBGTng");
	this.shape_32.setTransform(184.7,266.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#80D1DF").s().p("AoBDOIg4xjIRcIhIAXUKg");
	this.shape_33.setTransform(185.4,264);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#80D1DF").s().p("AoCDVIg0xyIRnImIAGUVg");
	this.shape_34.setTransform(185.6,263.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#80D1DF").s().p("AoCDWIg0xzIRnImIAGUVg");
	this.shape_35.setTransform(186.1,261.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21}]}).to({state:[{t:this.shape_21}]},17).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_35}]},8).to({state:[]},3).wait(55));

	// CENTER
	this.instance_7 = new lib.Symbol9();
	this.instance_7.parent = this;
	this.instance_7.setTransform(241.3,249.3,1,1,0,0,0,42.5,48.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1).to({regY:41,y:241.4},0).wait(40).to({_off:true},1).wait(55));

	// Back-right
	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#80D1DF").s().p("AxDk7ITvBQIOYHpIvZA+g");
	this.shape_36.setTransform(348.9,259.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#80D1DF").s().p("Ax6kdISBg8IR0IGIxHCtg");
	this.shape_37.setTransform(354.4,256.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#80D1DF").s().p("AwRi4IOykGIRxILIt1Fyg");
	this.shape_38.setTransform(343.7,246.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#80D1DF").s().p("AuzhdIL3m8IRwISIq5Iig");
	this.shape_39.setTransform(334.2,237.9);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#80D1DF").s().p("AtggMIJSpeIRvIWIoTK/g");
	this.shape_40.setTransform(325.9,230);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#80D1DF").s().p("AsYA3IHDrnIRuIbImDNGg");
	this.shape_41.setTransform(318.6,223.2);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#80D1DF").s().p("ArbByIFKtdIRtIeIkJO5g");
	this.shape_42.setTransform(312.5,217.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#80D1DF").s().p("AqpCjIDnu+IRsIhIilQWg");
	this.shape_43.setTransform(307.5,212.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#80D1DF").s().p("AqCDIICZwIIRsIhIhXRhg");
	this.shape_44.setTransform(303.5,209.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#80D1DF").s().p("ApnDjIBjw+IRsIjIghSUg");
	this.shape_45.setTransform(300.7,206.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#80D1DF").s().p("ApWDzIBBxfIRsIlIABSzg");
	this.shape_46.setTransform(299.1,204.9);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#80D1DF").s().p("ApXD4IA3xpIRrIlIAMS+g");
	this.shape_47.setTransform(299.1,204.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_36}]}).to({state:[{t:this.shape_37}]},14).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47,p:{x:299.1,y:204.4}}]},1).to({state:[{t:this.shape_47,p:{x:298.2,y:204.1}}]},1).to({state:[]},17).wait(55));

	// Back-left
	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#9BD8DF").s().p("AjjiYITdjBIwfI7IvUB4g");
	this.shape_48.setTransform(137.3,263.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#9BD8DF").s().p("AuXC4INln9IPKBVIwaI2g");
	this.shape_49.setTransform(147.1,252.9);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#9BD8DF").s().p("AtABJIOooHILZFMIwUIxg");
	this.shape_50.setTransform(155.8,240.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#9BD8DF").s().p("Ar1gVIPloSIIGIhIwQIug");
	this.shape_51.setTransform(163.3,229.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#9BD8DF").s().p("Aq2hmIQZoZIFULTIwNIsg");
	this.shape_52.setTransform(169.6,220.3);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#9BD8DF").s().p("AqDipIREofIDCNnIwKIqg");
	this.shape_53.setTransform(174.8,212.8);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#9BD8DF").s().p("ApajdIRkojIBRPaIwIIng");
	this.shape_54.setTransform(178.8,206.9);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#9BD8DF").s().p("Ao9kBIR7onIAAQsIwGIlg");
	this.shape_55.setTransform(181.7,202.7);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#9BD8DF").s().p("ApEkYISJopIgwReIwGIlg");
	this.shape_56.setTransform(185.8,200.3);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#9BD8DF").s().p("ApGkfISNoqIhARuIwFIkg");
	this.shape_57.setTransform(187.2,199.4);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#9BD8DF").s().p("Ao0gFIgSkaIMsmCIFhioIhARuIwFIkg");
	this.shape_58.setTransform(186.2,199.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_48}]}).to({state:[{t:this.shape_48}]},6).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[]},26).wait(55));

	// Middlwe
	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#B4DADE").s().p("Ax5g9IQjo+ITRKIIyZJvg");
	this.shape_59.setTransform(247.5,291.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_59).to({_off:true},42).wait(55));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(285.5,-0.8,442.2,688);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;